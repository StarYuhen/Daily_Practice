<html>
 <head>
   <meta http-equiv="content-type" content="text/html;charset=utf-8"/>
 </head>
   <a href="login.php" target="frame3">用户登录</a> </br>
   <a href="enter.php" target="frame3">用户注册</a> </br>
   <a href="goodslist.php" target="frame3">商品列表</a> </br> 
   <a href="goodsadd.php" target="frame3">商品添加</a> </br>
   <a href="typelist.php" target="frame3">分类列表</a> </br>
   <a href="typeadd.php" target="frame3">分类添加</a> </br>

</html>